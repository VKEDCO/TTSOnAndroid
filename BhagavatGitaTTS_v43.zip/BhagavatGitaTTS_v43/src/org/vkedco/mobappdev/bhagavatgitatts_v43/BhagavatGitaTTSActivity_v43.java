package org.vkedco.mobappdev.bhagavatgitatts_v43;


import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class BhagavatGitaTTSActivity_v43 extends Activity 
implements OnInitListener, OnClickListener
{
	static final String LOGTAG = BhagavatGitaTTSActivity_v43.class.getCanonicalName() + "_TAG";
	
    // This is where you define the request type constants.
    static final int REQ_TTS_STATUS_CHECK = 0;
    BhagavatGitaApp_v43 mApp = null;
    Button mBtnSayInSN = null;
    Button mBtnSayInRU = null;
    Button mBtnSayInEN = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_bhagavat_gita_tts);
		
		mApp = (BhagavatGitaApp_v43) this.getApplication();
		
	    
	    this.mBtnSayInSN = (Button) this.findViewById(R.id.btnSayInSN);
	    this.mBtnSayInRU = (Button) this.findViewById(R.id.btnSayInRU);
	    this.mBtnSayInEN = (Button) this.findViewById(R.id.btnSayInEN);
	    
	    this.mBtnSayInSN.setOnClickListener(this);
	    this.mBtnSayInRU.setOnClickListener(this);
	    this.mBtnSayInEN.setOnClickListener(this);
	    
	    Intent i = new Intent();
        i.setAction(TextToSpeech.Engine.ACTION_CHECK_TTS_DATA);
	    startActivityForResult(i, REQ_TTS_STATUS_CHECK);
	}
	
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	if ( requestCode == REQ_TTS_STATUS_CHECK ) {
    		switch ( resultCode ) {
    		case TextToSpeech.Engine.CHECK_VOICE_DATA_PASS:
    			Log.v(BhagavatGitaTTSActivity_v43.LOGTAG, "TTS installed");
    			mApp.setTTS(new TextToSpeech(this, this));
    			break;
    		case TextToSpeech.LANG_MISSING_DATA:
    		case TextToSpeech.Engine.CHECK_VOICE_DATA_FAIL:
    				Log.v(BhagavatGitaTTSActivity_v43.LOGTAG, "TTS installation failure");
        			Intent installIntent = new Intent();
        			installIntent.setAction(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA);
        			startActivity(installIntent);
        			break;
    		}
    	}
    	else {
    		Log.v(BhagavatGitaTTSActivity_v43.LOGTAG, "Unknown request code: " + requestCode);
    	}
    }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.bhagavat_gita_tt, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onInit(int status) {
		if ( status == TextToSpeech.SUCCESS ) {
			Log.v(LOGTAG, "staus == success");
			mApp.addWordsToTTS();
			this.mBtnSayInSN.setEnabled(true);
			this.mBtnSayInRU.setEnabled(true);
			this.mBtnSayInEN.setEnabled(true);
		}
		else {
			Log.v(LOGTAG, "staus == failure");
		}
		
	}

	@Override
	public void onClick(View v) {
		switch ( v.getId() ) {
		case R.id.btnSayInSN: mApp.saySanskritWords(); 	return;
		case R.id.btnSayInRU: mApp.sayRussianWords(); 	return;
		case R.id.btnSayInEN: mApp.sayEnglishWords(); 	return;
		}
	}
	
	
}
