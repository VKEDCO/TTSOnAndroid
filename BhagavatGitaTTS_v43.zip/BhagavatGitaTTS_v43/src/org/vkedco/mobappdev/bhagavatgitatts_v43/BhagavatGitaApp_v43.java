package org.vkedco.mobappdev.bhagavatgitatts_v43;

import android.app.Application;
import android.os.Environment;
import android.speech.tts.TextToSpeech;

public class BhagavatGitaApp_v43 extends Application {
	
	TextToSpeech mTTS = null;
	String[] mSNWords = null;
	String[] mRUWords = null;
	String[] mENWords = null;
	
	final static String SN_DIR = "/bhagavatgita/sn/";
	final static String RU_DIR = "/bhagavatgita/ru/";
	
	public BhagavatGitaApp_v43() {
		super();
	}
	
	public void setTTS(TextToSpeech tts) {
		mTTS = tts;
		mTTS.setOnUtteranceProgressListener(new MyUtteranceProgressListener());
	}
	
	public void speakWord(String word) {
		mTTS.speak(word, TextToSpeech.QUEUE_ADD, null);
	}
	
	public void onLowMemory() {
		if ( mTTS != null )
			mTTS.shutdown();

	}
	
	public void onTerminate() {
		if ( mTTS != null )
			mTTS.shutdown();
	}

	public void addWordsToTTS() {
		
		mSNWords = getResources().getStringArray(R.array.sn_words);
		mRUWords = getResources().getStringArray(R.array.ru_words);
		mENWords = getResources().getStringArray(R.array.en_words);
		
		// Add Sanskrit words
		final String snPath = Environment.getExternalStorageDirectory().getPath() + SN_DIR;
		mTTS.addSpeech("sn_akurvata", 		snPath + "sn_akurvata.wav");
		mTTS.addSpeech("sn_dharmakshetre", 	snPath + "sn_dharmakshetre.wav");
		mTTS.addSpeech("sn_kim", 			snPath + "sn_kim.wav");
		mTTS.addSpeech("sn_kurukshetre", 	snPath + "sn_kurukshetre.wav");
		mTTS.addSpeech("sn_mamakah", 		snPath + "sn_mamakah.wav");
		mTTS.addSpeech("sn_pandavashcaiva", snPath + "sn_pandavashcaiva.wav");
		mTTS.addSpeech("sn_samaveta", 		snPath + "sn_samaveta.wav");
		mTTS.addSpeech("sn_samjaya", 		snPath + "sn_samjaya.wav");
		mTTS.addSpeech("sn_yuyutsavah", 	snPath + "sn_yuyutsavah.wav");
		
		// Add Russian words
		final String ruPath = Environment.getExternalStorageDirectory().getPath() + RU_DIR;
		mTTS.addSpeech("ru_bitvy", 			ruPath + "ru_bitvy.wav");
		mTTS.addSpeech("ru_chto", 			ruPath + "ru_chto.wav");
		mTTS.addSpeech("ru_dharmy", 		ruPath + "ru_dharmy.wav");
		mTTS.addSpeech("ru_i", 				ruPath + "ru_i.wav");
		mTTS.addSpeech("ru_kurukshetry", 	ruPath + "ru_kurukshetry.wav");
		mTTS.addSpeech("ru_moi", 			ruPath + "ru_moi.wav");
		mTTS.addSpeech("ru_na", 			ruPath + "ru_na.wav");
		mTTS.addSpeech("ru_pandavy", 		ruPath + "ru_pandavy.wav");
		mTTS.addSpeech("ru_pole", 			ruPath + "ru_pole.wav");
		mTTS.addSpeech("ru_radi", 			ruPath + "ru_radi.wav");
		mTTS.addSpeech("ru_sandzhaya", 		ruPath + "ru_sandzhaya.wav");
		mTTS.addSpeech("ru_skazhi", 		ruPath + "ru_skazhi.wav");
		mTTS.addSpeech("ru_svershali", 		ruPath + "ru_svershali.wav");
		mTTS.addSpeech("ru_synovya", 		ruPath + "ru_synovya.wav");
		mTTS.addSpeech("ru_soydyas", 		ruPath + "ru_soydyas.wav");
	}
	
	final static String SN_PREFIX = "sn_";
	public void saySanskritWords() {
		for(String w: mSNWords)
			speakWord(SN_PREFIX + w);
	}
	
	final static String RU_PREFIX = "ru_";
	public void sayRussianWords() {
		for(String w: mRUWords)
			speakWord(RU_PREFIX + w);
	}
	
	
	public void sayEnglishWords() {
		for(String w: mENWords)
			speakWord(w);
	}

}
