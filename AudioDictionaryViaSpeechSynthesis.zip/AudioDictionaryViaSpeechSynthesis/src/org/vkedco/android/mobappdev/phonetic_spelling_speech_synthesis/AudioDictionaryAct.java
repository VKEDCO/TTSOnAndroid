package org.vkedco.android.mobappdev.phonetic_spelling_speech_synthesis;

import java.io.File;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.content.Intent;
import android.media.MediaPlayer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

// bugs to vladimir dot kulyukin at gmail dot com
public class AudioDictionaryAct extends Activity implements OnInitListener {
	EditText edTxtPhoneticSpelling 	= null;
	Button btnSpeak 				= null;
	EditText edTxtUserFileName 		= null;
	Button btnRecord 				= null;
	Button btnPlay 					= null;
	EditText edTxtRealSpelling 		= null;
	Button btnAssociate 			= null;
	String soundFilename 			= null;
	File soundFile 					= null;
	TextToSpeech mTTS 				= null;
	MediaPlayer mPlayer 			= null;
	TextView tvFileName 			= null;
	String mSDCardFolder 			= null;
	
    static final String AUDIO_ASSOCIATED_MSG 		= "Recording associated";
    static final String AUDIO_FILE_CREATED_MSG 		= "Audio file created";
    static final String AUDIO_FILE_NOT_CREATED_MSG 	= "Audio file not created";
    static final String CANNOT_PLAY_AUDIO_MSG 		= "Cannot play this audio file";
    static final String TTS_INSTALLED_MSG 			= "TTS installed";
    static final String TTS_UNAVAILABLE_MSG 		= "TTS not available";
    static final String INSTALL_TTS_DATA_MSG 		= "Attempting to install TTS data";
    static final int 	REQ_TTS_STATUS_CHECK 		= 0;
	static final String TAG 						= "TTS Demo";
			
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phonetic_spelling);
        
        edTxtPhoneticSpelling = (EditText)findViewById(R.id.edTxtWordsToSpeak);
        edTxtUserFileName = (EditText)findViewById(R.id.edTxtFilename);
        edTxtRealSpelling = (EditText)findViewById(R.id.edTxtRealSpelling);
        mSDCardFolder = Environment.getExternalStorageDirectory() + "/phonetic_spelling/";
        btnSpeak = (Button)findViewById(R.id.btnSpeak);
        btnSpeak.setOnClickListener(new OnClickListener() {
        	public void onClick(View view) {
        		mTTS.speak(edTxtPhoneticSpelling.getText().toString(), TextToSpeech.QUEUE_ADD, null);
        	}
        });
        
        btnRecord = (Button)findViewById(R.id.btnRecord);
        btnRecord.setOnClickListener(new OnClickListener() {
        	public void onClick(View view) {
        		soundFilename = mSDCardFolder + edTxtUserFileName.getText().toString();
        		soundFile = new File(soundFilename);
        		if (soundFile.exists()) {
        			soundFile.delete();
        		}
        		
        		if (mTTS.synthesizeToFile(edTxtPhoneticSpelling.getText().toString(), null,
        				soundFilename) == TextToSpeech.SUCCESS ) {
        			Toast.makeText(getBaseContext(), AUDIO_FILE_CREATED_MSG, 
        					Toast.LENGTH_SHORT).show();
        			btnPlay.setEnabled(true);
        			btnAssociate.setEnabled(true);
        		}
        		else {
        			Toast.makeText(getBaseContext(), AUDIO_FILE_NOT_CREATED_MSG,
        					Toast.LENGTH_SHORT).show();
        		}
        		
        	}
        });
        
        btnPlay = (Button)findViewById(R.id.btnPlay);
        btnPlay.setOnClickListener( new OnClickListener() {
        	public void onClick(View view) {
        		try {
        			Log.v("AUDIODICTIONARY", soundFilename);
        			mPlayer = new MediaPlayer();
        			mPlayer.setDataSource(soundFilename);
        			mPlayer.prepare();
        			mPlayer.start();
        		}
        		catch (Exception e) {
        			Toast.makeText(getBaseContext(),
        					CANNOT_PLAY_AUDIO_MSG,
        					Toast.LENGTH_SHORT).show();
        			e.printStackTrace();
        		}
        	}
        });
        
        btnAssociate = (Button)findViewById(R.id.btnAssociate);
        btnAssociate.setOnClickListener(new OnClickListener() {
        	public void onClick(View view) {
        		mTTS.addSpeech(edTxtRealSpelling.getText().toString(), soundFilename);
        		Toast.makeText(getBaseContext(),
        				AUDIO_ASSOCIATED_MSG,
        				Toast.LENGTH_SHORT).show();
        	}
        });
        
        // Initialize TTS
        Intent checkIntent = new Intent();
        checkIntent.setAction(TextToSpeech.Engine.ACTION_CHECK_TTS_DATA);
        startActivityForResult(checkIntent, REQ_TTS_STATUS_CHECK);
    }
    
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	if ( requestCode == REQ_TTS_STATUS_CHECK ) {
    		switch ( resultCode ) {
    		case TextToSpeech.Engine.CHECK_VOICE_DATA_PASS:
    			mTTS = new TextToSpeech(this, this);
    			Log.v(TAG,  TTS_INSTALLED_MSG);
    			break;
    		case TextToSpeech.Engine.CHECK_VOICE_DATA_FAIL:
    			Log.v(TAG, INSTALL_TTS_DATA_MSG + resultCode);
    			Intent installTTSDataIntent = new Intent();
    			installTTSDataIntent.setAction(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA);
    			startActivity(installTTSDataIntent);
    			default:
    				Log.e(TAG, TTS_UNAVAILABLE_MSG);
    		}
    	}
    }
    
    public void onInit(int status) {
    	if ( status == TextToSpeech.SUCCESS ) {
    		btnSpeak.setEnabled(true);
    		btnRecord.setEnabled(true);
    	}
    }
    
    public void onPause() {
    	super.onPause();
    	if ( mPlayer != null ) {
    		mPlayer.stop();
    	}
    	
    	if ( mTTS != null ) {
    		mTTS.stop();
    	}	
    }
    
    public void onDestroy() {
    	super.onDestroy();
    	if ( mPlayer != null ) {
    		mPlayer.release();
    	}
    	if ( mTTS != null ) {
    		mTTS.shutdown();
    	}
    }
}