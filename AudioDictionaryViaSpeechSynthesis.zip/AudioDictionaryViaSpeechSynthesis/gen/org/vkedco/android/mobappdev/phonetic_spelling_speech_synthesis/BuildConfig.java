/** Automatically generated file. DO NOT MODIFY */
package org.vkedco.android.mobappdev.phonetic_spelling_speech_synthesis;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}