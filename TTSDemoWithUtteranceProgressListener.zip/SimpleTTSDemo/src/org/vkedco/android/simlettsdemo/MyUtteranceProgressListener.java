package org.vkedco.android.simlettsdemo;

import android.speech.tts.UtteranceProgressListener;
import android.util.Log;

class MyUtteranceProgressListener extends UtteranceProgressListener {

	final static String LOGTAG = MyUtteranceProgressListener.class.getCanonicalName() + "_LOG";
	
	@Override
	public void onStart(String utteranceId) {
		Log.v(MyUtteranceProgressListener.LOGTAG, "onStart(" + utteranceId + ")");
	}

	@Override
	public void onDone(String utteranceId) {
		Log.v(MyUtteranceProgressListener.LOGTAG, "onDone(" + utteranceId + ")");
	}

	@Override
	public void onError(String utteranceId) {
		Log.v(MyUtteranceProgressListener.LOGTAG, "onError(" + utteranceId + ")");
		
	}
}
