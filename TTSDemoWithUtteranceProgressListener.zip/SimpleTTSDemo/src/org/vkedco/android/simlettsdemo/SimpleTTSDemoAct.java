package org.vkedco.android.simlettsdemo;

import java.util.HashMap;
//import java.util.StringTokenizer;



import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;

public class SimpleTTSDemoAct extends Activity 
	implements OnInitListener, OnSeekBarChangeListener
{	
	final static String LOGTAG = SimpleTTSDemoAct.class.getCanonicalName() + "_LOG";
	int mUttCount = 0;
	HashMap<String, String> mTtsParams = new HashMap<String, String>();
    // gui components
	EditText mWordsToSpeak = null;
    Button mBtnSpeak = null;
    // This is where you define the request type constants.
    static final int REQ_TTS_STATUS_CHECK = 0;
    // this is the Android tts (PICO).
    TextToSpeech mTTS = null;
    TextView mSpeechPitchProgressTV = null; SeekBar mSpeechPitchSeekBar = null;
	TextView mSpeechRateProgressTV	= null; SeekBar mSpeechRateSeekBar = null;
	final float PITCH_RANGE = 50f;
	final float RATE_RANGE  = 50f;
	
	int mSpeechRateProgressValue  = 0;
	int mSpeechPitchProgressValue = 0;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        mWordsToSpeak = (EditText)findViewById(R.id.wordsToSpeak);
        mBtnSpeak = (Button)findViewById(R.id.speak);
        
        mBtnSpeak.setOnClickListener(new OnClickListener() {
        	public void onClick(View view) {
        		/*
        		// this method should be used if you want to do word by word TTS.
        		StringTokenizer st = 
        			new StringTokenizer(mWordsToSpeak.getText().toString(), ".,\n");
        		while ( st.hasMoreTokens() ) {
        			mTtsParams.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, 
        					String.valueOf(mUttCount++));
        			String tok = st.nextToken();
        			Log.v(LOGTAG, getResources().getString(R.string.about_to_speak) + " " + tok);
        			// add the entry to the queue and flush
        			mTTS.speak(tok, TextToSpeech.QUEUE_ADD, mTtsParams);
        		}
        		*/
        		mTTS.speak(mWordsToSpeak.getText().toString(), TextToSpeech.QUEUE_ADD, mTtsParams);
        	}
        });
        
        Intent checkTtsIntent = new Intent(TextToSpeech.Engine.ACTION_CHECK_TTS_DATA);
        // This is another way to set the intent's action.
    	// checkIntent.setAction(TextToSpeech.Engine.ACTION_CHECK_TTS_DATA);
    	startActivityForResult(checkTtsIntent, REQ_TTS_STATUS_CHECK);
    	this.mSpeechPitchProgressTV = (TextView)(this.findViewById(R.id.tvSpeechPitchValue));
    	this.mSpeechRateProgressTV = (TextView)(this.findViewById(R.id.tvSpeechRateValue));
    	this.mSpeechPitchSeekBar = (SeekBar)(this.findViewById(R.id.sbPitch));
    	this.mSpeechRateSeekBar = (SeekBar)(this.findViewById(R.id.sbRate));
    	
    	this.mSpeechPitchSeekBar.setEnabled(false);
    	this.mSpeechRateSeekBar.setEnabled(false);
    }
    
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	if ( requestCode == REQ_TTS_STATUS_CHECK ) {
    		switch ( resultCode ) {
    		case TextToSpeech.Engine.CHECK_VOICE_DATA_PASS:
    			mTTS = new TextToSpeech(this, this);
    			mTTS.setOnUtteranceProgressListener(new MyUtteranceProgressListener());
    			Log.d(SimpleTTSDemoAct.LOGTAG, getResources().getString(R.string.pico_installed_ok));
    			
    			break;
    		case TextToSpeech.LANG_MISSING_DATA:
    		case TextToSpeech.Engine.CHECK_VOICE_DATA_FAIL:
    				Log.d(SimpleTTSDemoAct.LOGTAG, getResources().getString(R.string.tts_unavailable));
    				Log.d(SimpleTTSDemoAct.LOGTAG, getResources().getString(R.string.need_tts_data) + " "+ resultCode);
        			Intent installIntent = new Intent();
        			installIntent.setAction(
        					TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA);
        			startActivity(installIntent);
        			break;
    		}
    	}
    	else {
    		Log.d(SimpleTTSDemoAct.LOGTAG, getResources().getString(R.string.unknown_request_code));
    	}
    }
    
	public void onInit(int status) {
		if ( status == TextToSpeech.SUCCESS ) {
			this.mBtnSpeak.setEnabled(true);
			this.mSpeechPitchSeekBar.setEnabled(true);
			this.mSpeechRateSeekBar.setEnabled(true);
			this.mSpeechPitchSeekBar.setOnSeekBarChangeListener(this);
			this.mSpeechRateSeekBar.setOnSeekBarChangeListener(this);
			this.mSpeechRateSeekBar.setProgress(50);
			this.mSpeechPitchSeekBar.setProgress(50);
			this.mSpeechRateProgressTV.setText("1");
			this.mTTS.setSpeechRate(1.0f);
			this.mSpeechPitchProgressTV.setText("1");
			this.mTTS.setPitch(1.0f);
		}
	}
	
	public void onStop() {
		super.onStop();
		if ( this.mTTS != null ) {
			this.mTTS.stop();
		}
	}
	
	public void onPause() {
		super.onPause();
		if ( this.mTTS != null ) {
			this.mTTS.stop();
		}
	}
	
	public void onDestroy() {
		super.onDestroy();
		this.mTTS.shutdown();
	}

	@Override
	public void onProgressChanged(SeekBar seekBar, int progress,
			boolean fromUser) {
		switch ( seekBar.getId() ) {
		case R.id.sbPitch: 
			this.mSpeechPitchProgressTV.setText(Float.toString(this.convertSpeechPitch(progress))); 
			this.mSpeechPitchProgressValue = progress;
			break;
		case R.id.sbRate: 
			this.mSpeechRateProgressTV.setText(Float.toString(this.convertSpeechRate(progress))); 
			this.mSpeechRateProgressValue = progress;
			break;
		}
	}

	@Override
	public void onStartTrackingTouch(SeekBar seekBar) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStopTrackingTouch(SeekBar seekBar) {
		switch ( seekBar.getId() ) {
		case R.id.sbPitch: 
			final float pitch = convertSpeechPitch(this.mSpeechPitchProgressValue);
			this.mTTS.setPitch(pitch);
			break;
		case R.id.sbRate: 
			final float rate = convertSpeechRate(this.mSpeechRateProgressValue);
			this.mTTS.setSpeechRate(rate);
			break;
		}
	}
	
	float convertSpeechRate(int progress) {
		return progress/RATE_RANGE;
	}
	
	float convertSpeechPitch(int progress) {
		return progress/PITCH_RANGE;
	}
}