/** Automatically generated file. DO NOT MODIFY */
package org.vkedco.android.bhagavatgitatts_intent_service_v43;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}