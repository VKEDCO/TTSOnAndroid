package org.vkedco.android.bhagavatgitatts_intent_service_v43;

/************************************************************
 * BhagavatGitaTTSActivity_v43.java implements the main activity
 * of the BhagavatGitaTTS application that shows how the user 
 * can overcome TTS limitations through human recording.
 * 
 * This application uses human recorded files for the words
 * of the first verse of Bhagavatgita in Sanskrit and Russian.
 * The recorded files are saved in /res/raw. The Sanskrit
 * files begin with sa_ and the Russian files begin with
 * ru_. 
 *
 * Bugs, comments to vladimir dot kulyukin at gmail dot com
 * Additional materials are available at 
 * 1) www.youtube.com/vkedco
 * 2) and www.vkedco.blogspot.com
 *************************************************************
 */

//import org.vkedco.android.bhagavatgitatts.R;



import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class BhagavatGitaTTSActivity_v43 extends Activity
	implements OnInitListener, OnClickListener
{
	private static final int REQ_TTS_STATUS_CHECK = 0;
	private static final String LOGTAG = "BhagavatGitaTTSAct";
	private BhagavatGitaApp_v43 mApp = null;
	private Button mSpeakRuBtn = null;
	private Button mSpeakSaBtn = null;
	private Button mSpeakEnBtn = null;
	private Resources mRes = null;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        mApp = (BhagavatGitaApp_v43)this.getApplication();
        mRes = getResources();
        mSpeakRuBtn = (Button)findViewById(R.id.speakRuBtn);
        mSpeakSaBtn = (Button)findViewById(R.id.speakSaBtn);
        mSpeakEnBtn = (Button)findViewById(R.id.speakEnBtn);
        
        mSpeakRuBtn.setOnClickListener(this);
        mSpeakSaBtn.setOnClickListener(this);
        mSpeakEnBtn.setOnClickListener(this);
        
        Intent i = new Intent();
        i.setAction(TextToSpeech.Engine.ACTION_CHECK_TTS_DATA);
        startActivityForResult(i, REQ_TTS_STATUS_CHECK);
    }
    
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	if ( requestCode == REQ_TTS_STATUS_CHECK ) {
    		switch ( resultCode ) {
    		case TextToSpeech.Engine.CHECK_VOICE_DATA_PASS:
    			mApp.setTTS(new TextToSpeech(this, this));
    			enableSpeakButtons();
    			Log.v(LOGTAG, "Pico is installed okay");
    			break;
    			/*
    			 * This stuff has been depreciated
    		case TextToSpeech.Engine.CHECK_VOICE_DATA_BAD_DATA:
    		case TextToSpeech.Engine.CHECK_VOICE_DATA_MISSING_DATA:
    		case TextToSpeech.Engine.CHECK_VOICE_DATA_MISSING_VOLUME:
    			Log.v(LOGTAG, "Need language stuff: " + resultCode);
    			Intent installIntent = new Intent();
    			installIntent.setAction(
    					TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA);
    			startActivity(installIntent);
    			break;
    			*/
    		case TextToSpeech.Engine.CHECK_VOICE_DATA_FAIL:
    			Log.v(LOGTAG, "Need language stuff: " + resultCode);
    			Intent installIntent = new Intent();
    			installIntent.setAction(
    					TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA);
    			startActivity(installIntent);
    			break;
    		default:
    				Log.e(LOGTAG, "Failure: TTS apparently not available");
    		}
    	}
    	else {
    		Log.e(LOGTAG, "I cannot figure out what is wrong");
    	}
    }

	@Override
	public void onInit(int status) {
		if ( status == TextToSpeech.SUCCESS ) {
    		mApp.addWords();
    	}
	}

	@Override
	public void onClick(View v) {
		if ( v.getId() == R.id.speakRuBtn ) {
			speakRussianGita();
		}
		else if ( v.getId() == R.id.speakSaBtn ) {
			speakSanskritGita();
		}
		else if ( v.getId() == R.id.speakEnBtn ) {
			speakEnglishGita();
		}
	}
	
	private void enableSpeakButtons() {
		mSpeakRuBtn.setEnabled(true);
		mSpeakSaBtn.setEnabled(true);
		mSpeakEnBtn.setEnabled(true);
	}
	
	private void speakRussianGita() {
		Intent speakI = new Intent(getApplicationContext(),
				TTSIntentService.class);
		String[] verse = {
				"chto", "svershali", "skazhi", "sandzhaya",
				"synovya", "moi", "i", "pandavy",
				"radi", "bitvy", "soydyas", "na", "pole",
				"kurukshetry", "na", "pole", "dharmy"
				
		};
		String wordKey = mRes.getString(R.string.word_key);
		for(String str : verse) {
			speakI.putExtra(wordKey, "ru_" + str);
			startService(speakI);
		}
	}
	
	private void speakSanskritGita() {
		Intent speakI = new Intent(getApplicationContext(),
				TTSIntentService.class);
		String[] verse = {
				"dharmakshetre", "kurukshetre", "samaveta", "yuyutsavah",
				"mamakah", "pandavashcaiva", "kim", "akurvata", "samjaya"
		};
		String wordKey = mRes.getString(R.string.word_key);
		for(String str : verse) {
			speakI.putExtra(wordKey, "sa_" + str);
			startService(speakI);
		}
	}
	
	private void speakEnglishGita() {
		Intent speakI = new Intent(getApplicationContext(),
				TTSIntentService.class);
		String[] verse = {
				"oh", "sanjaya", "tell", "me", "what", "happened", "at",
				"kurukshetra", "the", "field", "of", "dharma", "where", "my",
				"family", "and", "the", "Pandavas", "gathered", "to", "fight"
		};
		String wordKey = mRes.getString(R.string.word_key);
		for(String str : verse) {
			speakI.putExtra(wordKey, str);
			startService(speakI);
		}
	}
}