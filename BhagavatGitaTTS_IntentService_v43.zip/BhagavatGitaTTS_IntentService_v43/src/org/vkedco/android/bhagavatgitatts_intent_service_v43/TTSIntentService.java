package org.vkedco.android.bhagavatgitatts_intent_service_v43;

/************************************************************
 * TTSIntentService.java implements the IntentService of
 * the BhagavatGitaTTS application that shows how the user 
 * can overcome TTS limitations through human recording.
 * The IntentService accepts TTS intents for speaking
 * Sanskrit and Russian words.
 * 
 * This application uses human recorded files for the words
 * of the first verse of Bhagavatgita in Sanskrit and Russian.
 * The recorded files are saved in /res/raw. The Sanskrit
 * files begin with sa_ and the Russian files begin with
 * ru_. 
 *
 * Bugs, comments to vladimir dot kulyukin at gmail dot com
 * Additional materials are available at 
 * 1) www.youtube.com/vkedco
 * 2) and www.vkedco.blogspot.com
 *************************************************************
 */



import android.app.IntentService;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;

public class TTSIntentService extends IntentService {

	private Resources mRes = null;
	private BhagavatGitaApp_v43 mApp = null;

	public TTSIntentService() {
		super("TTSIntentService");
	}
	
	@Override
	public void onCreate() {
		super.onCreate();
		mRes = getResources();
		mApp = (BhagavatGitaApp_v43)getApplication();
	}

	@Override
	protected void onHandleIntent(Intent i) {
		Bundle args = i.getExtras();
		String wordKey = mRes.getString(R.string.word_key);
		String word = args.getString(wordKey);
		Log.v("TTSService", "about to speak");
		mApp.speakWord(word);
	}
}
