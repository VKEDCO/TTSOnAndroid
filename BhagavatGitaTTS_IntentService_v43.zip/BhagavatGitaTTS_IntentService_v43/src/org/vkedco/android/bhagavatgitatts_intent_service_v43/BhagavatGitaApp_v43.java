package org.vkedco.android.bhagavatgitatts_intent_service_v43;

/************************************************************
 * BhagavatGitaApp_v43.java customizes the Application class
 * of the BhagavatGitaTTS application that shows how the user 
 * can overcome TTS limitations through human recording.
 * 
 * This application uses human recorded files for the words
 * of the first verse of Bhagavatgita in Sanskrit and Russian.
 * The recorded files are saved in /res/raw. The Sanskrit
 * files begin with sa_ and the Russian files begin with
 * ru_. 
 *
 * Bugs, comments to vladimir dot kulyukin at gmail dot com
 * Additional materials are available at 
 * 1) www.youtube.com/vkedco
 * 2) and www.vkedco.blogspot.com
 *************************************************************
 */

//import org.vkedco.android.bhagavatgitatts.R;



import android.app.Application;
import android.speech.tts.TextToSpeech;
import android.util.Log;

public class BhagavatGitaApp_v43 extends Application
{
	private TextToSpeech mTTS = null;
	private static final String LOGTAG = "BhagavatGitaApp_v43";
	
	public BhagavatGitaApp_v43() {
		super();
	}
	
	public void setTTS(TextToSpeech tts) {
		mTTS = tts;
	}
	
	public void speakWord(String word) {
		mTTS.speak(word, TextToSpeech.QUEUE_ADD, null);
	}
	
	public void onLowMemory() {
		if ( mTTS != null )
			mTTS.shutdown();

	}
	
	public void onTerminate() {
		if ( mTTS != null )
			mTTS.shutdown();
	}
	
	public void addWords() {
		String pack = getResources().getString(R.string.app_pack);
		
		// Add Sanskrit words
		
		mTTS.addSpeech("sa_akurvata", pack, R.raw.sa_akurvata);
		mTTS.addSpeech("sa_dharmakshetre", pack, R.raw.sa_dharmakshetre);
		mTTS.addSpeech("sa_kim", pack, R.raw.sa_kim);
		mTTS.addSpeech("sa_kurukshetre", pack, R.raw.sa_kurukshetre);
		mTTS.addSpeech("sa_mamakah", pack, R.raw.sa_mamakah);
		mTTS.addSpeech("sa_pandavashcaiva", pack, R.raw.sa_pandavashcaiva);
		mTTS.addSpeech("sa_samaveta", pack, R.raw.sa_samaveta);
		mTTS.addSpeech("sa_samjaya", pack, R.raw.sa_samjaya);
		mTTS.addSpeech("sa_yuyutsavah", pack, R.raw.sa_yuyutsavah);
		
		
		// Add Russian words
		mTTS.addSpeech("ru_bitvy", pack, R.raw.ru_bitvy);
		
		mTTS.addSpeech("ru_chto", pack, R.raw.ru_chto);
		mTTS.addSpeech("ru_dharmy", pack, R.raw.ru_dharmy);
		mTTS.addSpeech("ru_i", pack, R.raw.ru_i);
		mTTS.addSpeech("ru_kurukshetry", pack, R.raw.ru_kurukshetry);
		mTTS.addSpeech("ru_moi", pack, R.raw.ru_moi);
		mTTS.addSpeech("ru_na", pack, R.raw.ru_na);
		mTTS.addSpeech("ru_pandavy", pack, R.raw.ru_pandavy);
		mTTS.addSpeech("ru_pole", pack, R.raw.ru_pole);
		mTTS.addSpeech("ru_radi", pack, R.raw.ru_radi);
		mTTS.addSpeech("ru_sandzhaya", pack, R.raw.ru_sandzhaya);
		mTTS.addSpeech("ru_skazhi", pack, R.raw.ru_skazhi);
		mTTS.addSpeech("ru_svershali", pack, R.raw.ru_svershali);
		mTTS.addSpeech("ru_synovya", pack, R.raw.ru_synovya);
		mTTS.addSpeech("ru_soydyas", pack, R.raw.ru_soydyas);
		
	    
	    Log.v(LOGTAG, "Words added to TTS");
	    
	    
	}
}
